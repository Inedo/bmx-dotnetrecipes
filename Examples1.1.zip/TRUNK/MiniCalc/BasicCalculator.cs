﻿using System;
using System.ComponentModel;

namespace MiniCalc
{
    /// <summary>
    /// Implements a simple calculator.
    /// </summary>
    public sealed class BasicCalculator : INotifyPropertyChanged
    {
        private decimal lvalue;
        private Func<decimal, decimal, decimal> deferredOperation;
        private string displayValue = "0";
        private bool overwrite;

        /// <summary>
        /// Initializes a new instance of the <see cref="BasicCalculator"/> class.
        /// </summary>
        public BasicCalculator()
        {
        }

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Gets the display value.
        /// </summary>
        public string DisplayValue
        {
            get { return this.displayValue; }
            private set
            {
                this.displayValue = value;
                OnPropertyChanged(new PropertyChangedEventArgs("DisplayValue"));
            }
        }

        /// <summary>
        /// Appends a digit to the displayed value.
        /// </summary>
        /// <param name="digit">The digit to append.</param>
        public void AppendDigit(int digit)
        {
            if (digit < 0 || digit > 9)
                throw new ArgumentOutOfRangeException("digit");

            if (this.overwrite || this.DisplayValue == "0")
                this.DisplayValue = digit.ToString();
            else
                this.DisplayValue += digit.ToString();

            this.overwrite = false;

        }
        /// <summary>
        /// Appends a decimal separator to the displayed value.
        /// </summary>
        public void AppendDecimalSeparator()
        {
            if (this.overwrite)
                this.DisplayValue = "0.";
            else if (!this.DisplayValue.Contains("."))
                this.DisplayValue += ".";

            this.overwrite = false;
        }

        /// <summary>
        /// Sets the Add operation.
        /// </summary>
        public void Add()
        {
            this.deferredOperation = (a, b) => a + b;
            SetLValue();
        }
        /// <summary>
        /// Sets the Subtract operation.
        /// </summary>
        public void Subtract()
        {
            this.deferredOperation = (a, b) => a - b;
            SetLValue();
        }
        /// <summary>
        /// Sets the Multiply operation.
        /// </summary>
        public void Multiply()
        {
            this.deferredOperation = (a, b) => a * b;
            SetLValue();
        }
        /// <summary>
        /// Sets the Divide operation.
        /// </summary>
        public void Divide()
        {
            this.deferredOperation = (a, b) => a / b;
            SetLValue();
        }

        /// <summary>
        /// Computes the factorial of the displayed value.
        /// </summary>
        public void Factorial()
        {
            this.DisplayValue = ExtraMath.Factorial(decimal.Parse(this.DisplayValue)).ToString();
            this.overwrite = true;
        }
        /// <summary>
        /// Computes the inverse of the displayed value.
        /// </summary>
        public void Inverse()
        {
            this.DisplayValue = (1m / decimal.Parse(this.DisplayValue)).ToString();
            this.overwrite = true;
        }
        /// <summary>
        /// Toggles the sign of the displayed value.
        /// </summary>
        public void ToggleSign()
        {
            this.DisplayValue = (-decimal.Parse(this.DisplayValue)).ToString();
        }

        /// <summary>
        /// Evaluates the current operation.
        /// </summary>
        public void Evaluate()
        {
            if (this.deferredOperation != null)
                this.DisplayValue = this.deferredOperation(this.lvalue, decimal.Parse(this.DisplayValue)).ToString();

            this.overwrite = true;
        }

        /// <summary>
        /// Clears the current value to 0.
        /// </summary>
        public void Clear()
        {
            this.DisplayValue = "0";
            this.lvalue = 0;
            this.deferredOperation = null;
            this.overwrite = false;
        }

        /// <summary>
        /// Sets the state needed for a deferred operation.
        /// </summary>
        private void SetLValue()
        {
            this.lvalue = decimal.Parse(this.DisplayValue);
            this.overwrite = true;
        }

        /// <summary>
        /// Raises the <see cref="E:PropertyChanged"/> event.
        /// </summary>
        /// <param name="e">The <see cref="System.ComponentModel.PropertyChangedEventArgs"/> instance containing the event data.</param>
        private void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            var handler = this.PropertyChanged;
            if (handler != null)
                handler(this, e);
        }
    }
}
