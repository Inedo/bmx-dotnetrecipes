﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace MiniCalc
{
    /// <summary>
    /// Minicalculator window.
    /// </summary>
    public sealed partial class MiniCalcWindow : Window
    {
        /// <summary>
        /// The MiniCalc dependency property definition.
        /// </summary>
        public static readonly DependencyProperty MiniCalcProperty = DependencyProperty.Register("MiniCalc", typeof(BasicCalculator), typeof(MiniCalcWindow));

        /// <summary>
        /// Initializes a new instance of the <see cref="MiniCalcWindow"/> class.
        /// </summary>
        public MiniCalcWindow()
        {
            InitializeComponent();
            this.MiniCalc = new BasicCalculator();
        }

        /// <summary>
        /// Gets or sets the BasicCalculator to use. This is a dependency property.
        /// </summary>
        public BasicCalculator MiniCalc
        {
            get { return (BasicCalculator)GetValue(MiniCalcProperty); }
            set { SetValue(MiniCalcProperty, value); }
        }

        /// <summary>
        /// Invoked when an unhandled <see cref="E:System.Windows.Input.Keyboard.KeyDown"/> attached event reaches an element in its route that is derived from this class. Implement this method to add class handling for this event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.Windows.Input.KeyEventArgs"/> that contains the event data.</param>
        protected override void OnKeyDown(KeyEventArgs e)
        {
            bool handled = true;

            switch (e.Key)
            {
                case Key.D0:
                case Key.NumPad0:
                    this.MiniCalc.AppendDigit(0);
                    break;
                case Key.D1:
                case Key.NumPad1:
                    this.MiniCalc.AppendDigit(1);
                    break;
                case Key.D2:
                case Key.NumPad2:
                    this.MiniCalc.AppendDigit(2);
                    break;
                case Key.D3:
                case Key.NumPad3:
                    this.MiniCalc.AppendDigit(3);
                    break;
                case Key.D4:
                case Key.NumPad4:
                    this.MiniCalc.AppendDigit(4);
                    break;
                case Key.D5:
                case Key.NumPad5:
                    this.MiniCalc.AppendDigit(5);
                    break;
                case Key.D6:
                case Key.NumPad6:
                    this.MiniCalc.AppendDigit(6);
                    break;
                case Key.D7:
                case Key.NumPad7:
                    this.MiniCalc.AppendDigit(7);
                    break;
                case Key.D8:
                case Key.NumPad8:
                    this.MiniCalc.AppendDigit(8);
                    break;
                case Key.D9:
                case Key.NumPad9:
                    this.MiniCalc.AppendDigit(9);
                    break;

                case Key.Decimal:
                    this.MiniCalc.AppendDecimalSeparator();
                    break;

                case Key.Add:
                    this.MiniCalc.Add();
                    break;
                case Key.Subtract:
                    this.MiniCalc.Subtract();
                    break;
                case Key.Multiply:
                    this.MiniCalc.Multiply();
                    break;
                case Key.Divide:
                    this.MiniCalc.Divide();
                    break;

                case Key.Enter:
                    this.MiniCalc.Evaluate();
                    break;

                default:
                    handled = false;
                    break;
            }

            if (handled)
                e.Handled = true;

            base.OnKeyDown(e);
        }

        #region Event Handlers
        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.Clear();
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.Add();
        }
        private void SubtractButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.Subtract();
        }
        private void MultiplyButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.Multiply();
        }
        private void DivideButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.Divide();
        }
        private void FactorialButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.Factorial();
        }
        private void InverseButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.Inverse();
        }
        private void ToggleSignButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.ToggleSign();
        }
        private void DecimalButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.AppendDecimalSeparator();
        }
        private void EvaluateButton_Click(object sender, RoutedEventArgs e)
        {
            this.MiniCalc.Evaluate();
        }
        private void NumberButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            this.MiniCalc.AppendDigit(int.Parse(button.Content.ToString()));
        }
        #endregion
    }
}
