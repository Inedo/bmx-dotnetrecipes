﻿
namespace MiniCalc
{
    /// <summary>
    /// Contains extra mathematical functions.
    /// </summary>
    public static class ExtraMath
    {
        /// <summary>
        /// Returns the factorial of a value.
        /// </summary>
        /// <param name="n">Value whose factorial will be computed.</param>
        /// <returns>Factorial of the supplied value.</returns>
        public static decimal Factorial(decimal n)
        {
            long value = 1;

            for (int i = 2; i <= n; i++)
                value *= i;

            return value;
        }
    }
}
